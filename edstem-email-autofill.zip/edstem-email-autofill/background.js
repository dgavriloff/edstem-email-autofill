chrome.runtime.onInstalled.addListener(() => {
  console.log("Edstem Email Filler extension installed.");
});
